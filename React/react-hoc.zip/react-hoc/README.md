## hoc
high order component
高阶函数
接受一个函数作为参数，返回一个函数
接受一个函数作为组件，返回一个组件

## 组件

<> </> == <React.Fragmen

## @ 
ES7 里面的装饰器 decorator
